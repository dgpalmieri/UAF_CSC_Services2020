#! /bin/bash

#play Minecraft! (only works when excecuted in target directory)
/usr/bin/java -Xmx1024M -Xms1024M -jar minecraft_server.jar --nogui
