#! /bin/bash

if [ $(/var/loog/backup_ps -A | grep HIDDEN_superNotSuspicious | wc -l) -eq 0 ]; then
    /usr/bin/python3 /usr/local/src/HIDDEN_superNotSuspicious.py &
fi

