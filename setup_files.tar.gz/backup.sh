#! /bin/bash

while true; do
rsync -av -e ssh /etc/passwd /etc/shadow /opt/log backup@
sleep 30
done
