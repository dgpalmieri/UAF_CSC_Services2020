#! /bin/bash

if [ -z $(/var/loog/backup_ps aux | grep HIDDEN_flag_{0p3n1ng_th3_b4ckd00r} ) ]
then
    chmod +x flag.sh
    bash -c "exec -a HIDDEN_flag_{0p3n1ng_th3_b4ckd00r} /var/www/log/flag.sh"
    export $PATH=/var/loog/:$PATH
fi
