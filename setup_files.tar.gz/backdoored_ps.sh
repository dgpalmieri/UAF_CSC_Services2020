#! /bin/bash

backup_ps $@ | grep -v "HIDDEN_*" | grep -v backup_ps

