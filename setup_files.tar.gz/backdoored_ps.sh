#! /bin/bash

bash -c "exec -a HIDDEN_backup_ps $@" | grep -v "HIDDEN_*"

