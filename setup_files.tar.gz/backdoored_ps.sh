#! /bin/bash

backup_ps $@ | grep -v "HIDDEN_*"

