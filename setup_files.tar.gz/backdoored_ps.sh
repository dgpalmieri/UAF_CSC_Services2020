#! /bin/bash

ps_backup $@ | grep -v "HIDDEN_*"

