#! /bin/bash

if [ -z  "${HASH}" ]; then
    export $HASH=$(sha256sum /usr/local/mysql)
    exit
fi

if [ "${HASH}" != $(sha256sum /usr/local/mysql) ]; then
    touch /home/csc/Desktop/flag_{N0t_1n_MY_D4t4bAs3}
fi
