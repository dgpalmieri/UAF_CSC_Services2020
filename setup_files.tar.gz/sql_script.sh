#! /bin/bash

if [ "${HASH}" != $(sha256sum $(find /var/lib/mysql -name "*") | sha26sum) ]; then
    touch /home/csc/flag_{N0t_1n_MY_D4t4bAs3}
fi
